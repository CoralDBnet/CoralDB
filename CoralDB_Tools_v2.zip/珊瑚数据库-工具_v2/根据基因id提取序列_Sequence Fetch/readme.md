## 功能说明

根据用户提供的基因 ID 列表，从 PEP 和/或 CDS 序列文件中批量提取对应序列。

## 运行方式

### 命令行

```bash
# 仅提取 PEP 序列
python geneid_get_seq_v2.py -g gene_id.txt -p Adu.pep -op pep_result.fasta

# 仅提取 CDS 序列
python geneid_get_seq_v2.py -g gene_id.txt -c Adu.cds -oc cds_result.fasta

# 同时提取 PEP 和 CDS 序列
python geneid_get_seq_v2.py -g gene_id.txt -p Adu.pep -op pep_result.fasta -c Adu.cds -oc cds_result.fasta
```

| 参数 | 说明 |
|------|------|
| `-g`, `--genes` | 基因ID的输入文件（每行一个基因ID，必填） |
| `-p`, `--pep` | 输入的PEP序列文件（可选） |
| `-c`, `--cds` | 输入的CDS序列文件（可选） |
| `-op`, `--output_pep` | PEP输出结果文件（与 `-p` 配对使用） |
| `-oc`, `--output_cds` | CDS输出结果文件（与 `-c` 配对使用） |

### 网页工具

**输入方式：**

- **基因 ID 输入框**：在文本输入框中粘贴基因 ID，每行一个
- **物种选择**：从下拉列表中选择目标物种
- **序列类型**：选择提取 CDS 或 PEP 序列

**输出说明：**

提取结果在页面显示，每条序列附带**复制**按钮，方便快速获取单条序列。完整结果支持**下载**为 FASTA 文件。

## 注意事项

- 基因 ID 需与数据库中 FASTA 头部完全匹配
- CDS 和 PEP 各自独立提取，互不影响
- 未匹配到的基因 ID 将提示未找到序列
- 至少需提供 `-p` 或 `-c` 其中一个

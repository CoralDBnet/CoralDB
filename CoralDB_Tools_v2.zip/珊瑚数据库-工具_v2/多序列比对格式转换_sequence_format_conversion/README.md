## 功能说明

将多序列比对文件从一种格式转换为另一种格式。基于 Biopython SeqIO 模块，支持 19 种主流多序列比对格式。

## 运行方式

### 命令行

```bash
python input_seq.py -i input.aln -o output.fasta -if clustal -of fasta
```

| 参数 | 说明 |
|------|------|
| `-i`, `--input` | 输入的多序列比对文件 |
| `-o`, `--output` | 输出的结果文件 |
| `-if`, `--input-format` | 输入文件格式（如 clustal, fasta, phylip 等） |
| `-of`, `--output-format` | 输出文件格式（如 fasta, clustal, phylip 等） |

### 网页工具

**输入方式：**

- **上传文件**：支持上传多序列比对文件（限制 1MB 以内）
- **文本输入框**：直接在输入框中粘贴文件内容

页面提供两个下拉菜单：
1. **输入格式**：选择当前文件的格式
2. **输出格式**：选择想要转换的目标格式

**输出说明：**

转换结果在页面直接显示，支持**复制**和**下载**。

## 支持的格式（共 19 种）

| 格式名 | 说明 |
|--------|------|
| clustal | ClustalW 多序列比对 |
| embl | EMBL 格式 |
| fasta | FASTA 格式 |
| fasta-2line | FASTA（序列不折行） |
| fastq | FASTQ 质量分数 |
| fastq-illumina | Illumina FASTQ |
| fastq-sanger | Sanger FASTQ |
| fastq-solexa | Solexa FASTQ |
| gb | GenBank 格式 |
| genbank | GenBank 格式（别名） |
| nexus | NEXUS 格式 |
| phylip | PHYLIP 交错格式 |
| phylip-relaxed | PHYLIP 宽松格式 |
| phylip-sequential | PHYLIP 顺序格式 |
| pir | PIR / NBRF 格式 |
| qual | 质量分数格式 |
| seqxml | SeqXML 格式 |
| stockholm | Stockholm 格式 |
| tab | 制表符分隔格式 |

## 注意事项

- 单次仅转换一个文件，不处理批量转换
- 部分格式之间有信息损失（如 GenBank 转 FASTA 会丢失注释），请根据需求选择输入输出格式
